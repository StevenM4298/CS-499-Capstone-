// ProjectTwo.cpp 
// Steven Mathias
// CS 300 Analysis and Design
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <unordered_map>

using namespace std;


//Course class
class Course {
public:      //Create string attributes of the data fields in each line
    string courseName;
    string courseNumber;
    string prerequisiteId;

    //Constructor
    Course(string n, string num, string pre) : courseName(n), courseNumber(num), prerequisiteId(pre) {}
};

//Remove whitespace from the string lines
string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t");
    if (first == string::npos) return "";
    size_t last = str.find_last_not_of(" \t");
    return str.substr(first, last - first + 1);
}

//Function for split function to separate fields into tokens 
vector<string> split(const string& str, char delimiter) {
    vector<string> tokens;
    string token;
    for (char c : str) {      //Splits parts of line by comma 
        if (c == delimiter) {
            if (!token.empty()) {
                tokens.push_back(trim(token));      //adds token to vector 
                token.clear();
            }
        }
        else {
            token += c;
        }
    }
    if (!token.empty()) {
        tokens.push_back(trim(token));
    }
    return tokens;
}


//Load file data into the program
void loadData(unordered_map<string, Course>& hashTable) {
    
    ifstream file("CourseList.txt");
    if (!file.is_open()){
        cout << "Error opening file" << endl;
        return;
    }

    //Parse each line from the data file and associates a token to store in the hash table
    string line;
    int lineNum = 0;
    while (getline(file, line)) {
        lineNum++;
        if (line.empty()) continue;

        vector<string> tokens = split(line, ',');

        if (tokens.size() < 2) {
            cout << "Invalid format" << lineNum << " " << line << endl;
            continue;
        }
        string courseName = tokens[1];
        string courseNumber = tokens[0];
        string prerequisiteId = tokens.size() > 3 ? tokens[2] : "none";

        hashTable.emplace(courseNumber, Course(courseName, courseNumber, prerequisiteId));
    }

    file.close();  // Close the file
}

//Extract the numerical values in order to sort later alphanumerically 
int extractNumber(const string& courseNumber) {
    string digits;
    for (char c : courseNumber) {
        if (isdigit(c)) {
            digits += c;
        }
    }
    return digits.empty() ? 0 : stoi(digits); // Convert to int, default to 0 if no digits
}


//Function to print full list in alphanumerical order
void printCourseList(const unordered_map<string, Course>& hashTable) {      //First check if hash table is empty
    if (hashTable.empty()) {
        cout << "No courses available." << endl;
        return;
    }

    //create vector of hash table to sort
    vector<pair<string, Course>> sortedCourses(hashTable.begin(), hashTable.end());
    
    sort(sortedCourses.begin(), sortedCourses.end(),
        [](const pair<string, Course>& a, const pair<string, Course>& b) {
            int numA = extractNumber(a.second.courseNumber);
            int numB = extractNumber(b.second.courseNumber);
            if (numA != numB) {
                return numA < numB; 
            }
            return a.second.courseNumber < b.second.courseNumber;
        });

    // Print sorted courses
    cout << "Course list:" << endl;
    for (const auto& pair : sortedCourses) {
        cout << "Number: " << pair.second.courseNumber
            << ", Course: " << pair.second.courseName
            << ", Prerequisite: " << (pair.second.prerequisiteId.empty() ? "None" : pair.second.prerequisiteId)
            << endl;
    }
}


// Print details for a specific course
void printSpecificCourse(const unordered_map<string, Course>& hashTable) {
    cout << "Enter course number: ";      //prompt the user for a course number
    string courseNumber;
    getline(cin, courseNumber);
    courseNumber = trim(courseNumber);

    auto it = hashTable.find(courseNumber);      //Determines whether the course number exists
    if (it == hashTable.end()) {
        cout << "Error: Course " << courseNumber << " not found." << endl;
    }
    else {      //Print the desired course information based on user input 
        cout << "Course: " << it->second.courseName
            << ", Number: " << it->second.courseNumber
            << ", Prerequisite: " << (it->second.prerequisiteId.empty() ? "None" : it->second.prerequisiteId)
            << endl;
    }
}


    
//Menu function for displaying user choices
void displayMenu() {
    cout << "\nWelcome to the course planner:\n"
        << "\n"
        << "1. Load data\n"
        << "2. Print list of courses\n"
        << "3. Print course name and prerequisite ID\n"
        << "4. Exit program\n"
        << "\n"
        << "Enter a choice (1-4): ";
    return;
};



//Main method
int main()
{
    unordered_map<string, Course> hashTable;
    while (true) {      //Display menu and choices
        displayMenu();
        string courseNumber;
        int choice;         //integer variable for user input
        cin >> choice;      //accept user input for choice
        cin.ignore();       //clear input buffer
        switch (choice) {

            //Choice for loading data
        case 1:
            hashTable.clear();
            loadData(hashTable);
            cout << "Data loaded successfully." << endl;
            break;

        case 2:
            printCourseList(hashTable);
            break;

        case 3:
            printSpecificCourse(hashTable);
            break;

        case 4:
            cout << "Now exiting the program..." << endl;      //Exit the program
            cout << "Thank you for using the course planner!" << endl;
            return 0;

        default:
            cout << "Invalid input. Please enter choice (1-4): " << endl;      //Error message if user input is not 1-4
        }
    }
    return 0;
}